package com.iToolsV2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iToolsV2.entity.Tools;

@Repository
public interface ToolRepository extends JpaRepository<Tools, Integer> {

}
