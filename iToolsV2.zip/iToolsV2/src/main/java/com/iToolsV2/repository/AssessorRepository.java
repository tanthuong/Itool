package com.iToolsV2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iToolsV2.entity.Assessor;

@Repository
public interface AssessorRepository extends JpaRepository<Assessor, Integer> {
	List<Assessor> findByUserNameAndActiveAndLocked(String userName, boolean active, boolean locked);
}
