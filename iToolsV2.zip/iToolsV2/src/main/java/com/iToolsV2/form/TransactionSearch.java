package com.iToolsV2.form;

import java.util.Date;

import lombok.Data;

@Data
public class TransactionSearch {
	private String companyCode;
	private String toolCode; /*CTIID*/
	private int userId;
	private String transactionType;
	private String machineCode;
	private Date fromDate;
	private Date toDate;
	private String tray;
}
