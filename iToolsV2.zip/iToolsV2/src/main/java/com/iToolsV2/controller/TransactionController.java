package com.iToolsV2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.iToolsV2.dao.CompanyDAO;
import com.iToolsV2.dao.MachineDAO;
import com.iToolsV2.dao.ToolDAO;
import com.iToolsV2.entity.*;
import com.iToolsV2.form.TransactionReport;
import com.iToolsV2.form.TransactionSearch;
import com.iToolsV2.repository.AssessorRepository;
import com.iToolsV2.repository.MachineRepository;
import com.iToolsV2.repository.ToolRepository;
import com.iToolsV2.service.TrayService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class TransactionController {
	
	@Autowired
	private CompanyDAO companyDao;
	@Autowired
	private ToolRepository toolRepository;
	@Autowired
	private AssessorRepository assessorRepo;
	@Autowired
	private MachineRepository machineRepository;
	@Autowired
	private TrayService trayService;
	
	@GetMapping("/transaction")
	public String getReport(Model model, @ModelAttribute TransactionSearch searchForm) {
		List<TransactionReport> lstTransaction = new ArrayList<>();
		model.addAttribute("transactionSearch", new TransactionSearch());
		model.addAttribute("lstTransaction", lstTransaction);
		
		List<Company> lstCompany = companyDao.findAllCompany();
		model.addAttribute("lstCompany", lstCompany);
		
		List<Tools> lstTool = toolRepository.findAll();
		model.addAttribute("lstTool", lstTool);
		
		List<Assessor> lstUser = assessorRepo.findAll();
		model.addAttribute("lstUser", lstUser);
		
		List<Machine> lstMachine = machineRepository.findAll();
		model.addAttribute("lstMachine", lstMachine);
		
		model.addAttribute("lstTray", null);
		
		return "transaction/transaction";
	}
	
	@GetMapping("/getTrayByMachineCode")
    @ResponseBody
	public List<String> getTrayByMachineCode(@RequestParam String machineCode) {
		try {
			return trayService.findTrayByMachineCode(machineCode);
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	@PostMapping("/transaction/query")
	public List<TransactionReport> searchTransaction(Model model, @ModelAttribute TransactionSearch searchForm) {
		List<TransactionReport> lstResult = new ArrayList<>();
		
		return lstResult;
	}
}
